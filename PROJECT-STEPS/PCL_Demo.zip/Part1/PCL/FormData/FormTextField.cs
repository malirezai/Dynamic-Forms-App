﻿using System;
namespace PCL
{
	public class FormTextField: FormElement
	{
		public string PlaceHolderText;
		public int NumLines;
		public string Text;

	}
}

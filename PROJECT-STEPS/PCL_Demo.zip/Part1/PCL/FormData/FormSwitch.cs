﻿using System;
namespace PCL
{
	public class FormSwitch: FormElement
	{
		public bool DefaultValue;
		public bool Value;
		public string Text;
	}
}

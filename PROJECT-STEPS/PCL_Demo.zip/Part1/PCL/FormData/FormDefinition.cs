﻿using System;
using System.Collections.Generic;

namespace PCL
{
	public class FormDefinition
	{

		List<FormElement> Elements;

	}
}

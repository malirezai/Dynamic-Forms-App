﻿namespace PCL
{
	public class FormElement
	{
		public string LabelText;
		public bool Visibile;
	}
}
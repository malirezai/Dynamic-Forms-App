﻿using System;
namespace PCL
{
	public class FormLabel:FormElement
	{
		public FormLabel()
		{
		}
	}
}

﻿using System;
namespace PCL
{
	public class DatePicker:FormElement
	{
		public DateTime SelectedDate;
		public string LabelText;
		public bool Visibile = true;
	}
}

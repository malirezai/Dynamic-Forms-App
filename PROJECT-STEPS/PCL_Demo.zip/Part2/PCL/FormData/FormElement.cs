﻿namespace PCL
{
	public class FormElement
	{
		public string Type;
		public string LabelText;
		public bool Visibile = true;
	}
}
﻿using System;
using System.Threading.Tasks;

namespace PCL.Interfaces
{
	public interface IResourceFinder
	{
		string getFormString(string fileName);
	}
}

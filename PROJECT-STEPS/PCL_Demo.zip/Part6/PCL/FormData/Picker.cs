﻿using System;
using System.Collections.Generic;

namespace PCL
{
	public class Picker:FormElement
	{
		public int DefaultIndex;
		public string SelectedValue;
		public List<string> Values;
	}
}

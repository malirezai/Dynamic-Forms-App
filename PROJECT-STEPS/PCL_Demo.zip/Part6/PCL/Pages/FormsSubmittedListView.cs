﻿using System;
using Xamarin.Forms;

namespace PCL
{
	public class FormsSubmittedListView : ContentPage
	{

		public ListView FormsSubmittedList;


		public FormsSubmittedListView()
		{
		}
	}
}
